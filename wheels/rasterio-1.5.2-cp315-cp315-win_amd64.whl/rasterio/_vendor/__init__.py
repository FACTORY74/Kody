"""Vendored modules."""
