"""Vendored modules."""
